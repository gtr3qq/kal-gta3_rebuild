CDGENPS2 3.0 support the creation od images CDX (one track an full capacity) and UMCDR (two tracks and unofficial support) with checksum and work perfect in my test. 
The .ISO format in old versions, before  created corrupt images. Now it works perfectly. 

In other formats work perfect also (I have tested ;) )

CDGENPS2 3.0 support also, the conversion of ISO to CDX or UMCDR formats. See in menu->Advanced->Create CDX (or UMCDR) from ISO option.

ADVICE: In root folder use ONLY names 8+3 (ISO1). Names of 31 chars is not compatible with filesystem of PS2

LICENSE TERMS: This software is completely free for NOT commercial use. Of course, you cannot request responsibilities to me by the problems/damages that this software can cause

donations: http://www.ps2reality.net/~mavy/dona.html